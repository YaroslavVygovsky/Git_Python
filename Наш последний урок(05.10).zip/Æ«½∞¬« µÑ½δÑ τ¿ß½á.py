a=input();
x = isinstance(a, int)
print(x)
print("a is not integer:", x)
