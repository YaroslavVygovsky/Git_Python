name=["Yaroslav","Yulia","Artem"];
del_name=name.pop();
print(name);
print(del_name)
