mashine=["mersedes","VAZ","Lamborgini"];
message=f"Хочете ли вы эту машину, {mashine[1].title()}?"
print(message);
