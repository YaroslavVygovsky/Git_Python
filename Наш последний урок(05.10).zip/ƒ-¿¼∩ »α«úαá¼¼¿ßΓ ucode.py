name=input("Введите имя");
print("Я,",name,"-программист ucode")
