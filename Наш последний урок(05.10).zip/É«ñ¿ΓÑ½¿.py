parents=["Татьяна","Мария","Виктор"];
message=f"Приглашаю вас на день рождения, {[0].title()}?"
print(message);
print(message);

