mashin=["BMW","lada","mersedes","sedan","VAZ"];
mashin[2]=('lamborgini');
mashin.append('bugatti')
message=f"Хочете ли вы эту машину, {mashin[2]}?"
print(mashin[5]);
print(message)

