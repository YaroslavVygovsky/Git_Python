a=float(input('a= '))
if a>0:
    print('x=',a**0.5,a**0.5*(-1))
elif a==0:
    print('x=0')
else:
    print('Корней нет')
    
