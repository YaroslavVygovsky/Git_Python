a=int(input('a= '))
b=int(input('b= '))
if a>15:
    a=a+7
else:
    a=a-5
if b>15:
    b=b+7
else:
    b=b-5
print(a,b)
