name=[];
name.insert(1,"Mazda");
name.insert(0,"ducati");
del(name[0]);
print(name)
