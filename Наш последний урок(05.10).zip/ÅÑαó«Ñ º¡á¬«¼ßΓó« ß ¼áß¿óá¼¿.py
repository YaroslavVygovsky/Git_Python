mashin=["tesla","bmw","mersedes"]

print(mashin);
print(mashin[0]);
print(mashin[0].title());
print(mashin[0].title(),mashin[1].title());
print(mashin[2].title());
print(mashin[-1].title())
