a=float(input("Какой рост "));
if a>199:
    print("Это папа")
elif (a>150) and (a<200):
   print("Это мальчик")
else: 
    print("Это девочка");

