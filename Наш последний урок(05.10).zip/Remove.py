#mashin.remove("mersedes");
mashin=["mersedes","honda","bmw","lamborgini","tesla"];
#item='mersedes';
#mashin.remove(item);
#print(mashin);
#message=f"Остались такие машины {mashin[1].title()},{mashin[3].title()},{mashin[2].title()},{mashin[0].title()}"
#print(message);
#mashin.sort();
#print(mashin);
#mashin.sort(reverse=1);
#print(mashin);
#mashin.reverse();
t=len(mashin);
print(t)

