mashin=["BMW","lada","mersedes","sedan","VAZ"];
print(mashin);
print(mashin[2]);
print(mashin[3].title);
print(mashin[-2]);
