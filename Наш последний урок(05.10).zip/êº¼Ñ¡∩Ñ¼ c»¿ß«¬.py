mashin=["mersedes","honda","bmw"];
mashin[0]="VAZ";
print(mashin)
