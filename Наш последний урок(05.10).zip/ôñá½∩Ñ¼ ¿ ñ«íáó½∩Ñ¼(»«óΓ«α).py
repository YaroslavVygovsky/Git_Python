mashin=['sedan','BMW','VAZ','mersedess','honda'];
mashin.insert(2,'lamborgini');
del mashin[-1];
del_mashin=mashin.pop(3);
print(mashin);
print(del_mashin);
